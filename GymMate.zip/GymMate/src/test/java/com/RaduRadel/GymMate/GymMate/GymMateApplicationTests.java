package com.RaduRadel.GymMate.GymMate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymMateApplicationTests {

	@Test
	void contextLoads() {
	}

}
